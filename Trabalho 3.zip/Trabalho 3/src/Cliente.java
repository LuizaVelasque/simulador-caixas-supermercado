/**
 * Autoras: Lívia Viana Barbosa liviabarbosa.aluno@unipampa.edu.br
 *          Luiza de Campos Velasque Figueiredo luizavelasque.aluno@unipampa.edu.br
 * 
 * Esta classe demostra o ator cliente, sendo que o seu número sequencial é o que o 
 * identifica. Aqui se encontram operações relacionadas ao seu tempo de atendimento,
 * o qual é decrementado a cada passo da simulação.
 */
public class Cliente {
    private int numeroSequencial;
    private int tempoAtendimento;
    
    /**
     * Construtor da classe Cliente.
     * 
     * @param numeroSequencial O número sequencial que identifica o cliente.
     * @param tempoAtendimento O tempo de atendimento do cliente.
     */
    public Cliente(int numeroSequencial, int tempoAtendimento) {
        this.numeroSequencial = numeroSequencial;
        this.tempoAtendimento = tempoAtendimento;
    }
    
    public int getNumeroSequencial() {
        return numeroSequencial;
    }
    
    public int getTempoAtendimento() {
        return tempoAtendimento;
    }
    
    /**
     * Método para decrementar o tempo de atendimento do cliente.
     * 
     * O tempo de atendimento é decrementado em uma unidade, desde que seja maior que zero.
     */
    public void decrementarTempo() {
        if (tempoAtendimento > 0) {
            tempoAtendimento--;
        }
    }
}