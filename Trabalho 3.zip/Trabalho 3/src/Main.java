import java.util.Scanner;
/**
 * Autoras: Lívia Viana Barbosa liviabarbosa.aluno@unipampa.edu.br
 *          Luiza de Campos Velasque Figueiredo luizavelasque.aluno@unipampa.edu.br
 * 
 * Esta classe é responsável por aplicar o funcionamento geral do código.
 */
public class Main {
    public static void main(String[] args) {
        LimpaTerminal limpaTerminal = new LimpaTerminal();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o número de caixas: ");
        int numeroDeCaixas = scanner.nextInt();
        Supermercado supermercado = new Supermercado(numeroDeCaixas);
        limpaTerminal.limparTerminal();
        while (true) {
            System.out.println("Pressione Enter para simular um passo ou digite 'sair' para encerrar.");
            String entrada = scanner.nextLine();
            if (entrada.equalsIgnoreCase("sair")) {
                break;
            }
            supermercado.simularPasso();
        }
        scanner.close();
    }
}