import java.util.Random;
/**
 * Autoras: Lívia Viana Barbosa liviabarbosa.aluno@unipampa.edu.br
 *          Luiza de Campos Velasque Figueiredo luizavelasque.aluno@unipampa.edu.br
 * 
 * Classe que simula um supermercado com múltiplos caixas e clientes sendo atendidos.
 */
public class Supermercado {
    private Caixa[] caixas;
    private int contadorClientes;
    private Random random;
    
    /**
     * Construtor da classe Supermercado.
     *
     * Este construtor cria um novo supermercado com um número específico de caixas, 
     * determinado pelo parâmetro numeroDeCaixas. Ele percorre esse número de caixas, criando 
     * individualmente cada um deles como instâncias de Caixa, que são então armazenadas em um 
     * grupo chamado caixas. Além disso, ele inicia um contador chamado contadorClientes em zero 
     * para controlar a ordem de chegada dos clientes ao supermercado. Também cria um objeto random 
     * para gerar números aleatórios, que simula a chegada aleatória de novos clientes ao supermercado.
     * 
     * @param numeroDeCaixas O número de caixas que serão criados no supermercado.
     */
    public Supermercado(int numeroDeCaixas) {
        caixas = new Caixa[numeroDeCaixas];
        for (int i = 0; i < numeroDeCaixas; i++) {
            caixas[i] = new Caixa();
        }
        contadorClientes = 0;
        random = new Random();
    }
    
    /**
     * Método que simula a passagem de tempo no supermercado.
     * 
     * Este método executa um passo de simulação no supermercado, onde novos clientes podem chegar 
     * aleatoriamente e serem adicionados aos caixas, que então os atendem. Após cada iteração, o 
     * estado atual de cada caixa é exibido, mostrando o cliente sendo atendido, se houver, e a fila 
     * de espera.
     */
    public void simularPasso() {
        if (random.nextInt(100) < 10) {
            int tempoAtendimento = random.nextInt(11) + 5;
            Cliente novoCliente = new Cliente(contadorClientes++, tempoAtendimento);
            Caixa caixaComMenorFila = encontrarCaixaComMenorFila();
            caixaComMenorFila.adicionarCliente(novoCliente);
        }
        for (Caixa caixa : caixas) {
            caixa.atenderCliente();
        }
        exibirEstado();
    }
    
    /**
     * Método privado para encontrar o caixa com a menor fila de espera.
     * 
     * Itera sobre todos os caixas disponíveis no supermercado e compara o tamanho de suas filas.
     * Retorna o caixa com a menor fila encontrada.
     * 
     * @return O caixa com a menor fila de espera.
     */
    private Caixa encontrarCaixaComMenorFila() {
        Caixa caixaComMenorFila = caixas[0];
        for (Caixa caixa : caixas) {
            if (caixa.getFila().getTamanho() < caixaComMenorFila.getFila().getTamanho()) {
                caixaComMenorFila = caixa;
            }
        }
        return caixaComMenorFila;
    }
    
    /**
     * Método privado para exibir o estado atual de cada caixa no supermercado.
     * 
     * Imprime no console informações sobre cada caixa, incluindo o cliente sendo atendido (se houver)
     * e a lista de clientes na fila de espera (se tiver clientes na fila).
     */
    private void exibirEstado() {
        String corReset = "\u001B[0m";
        String corRoxo = "\u001B[35m";
        String corCiano = "\u001B[36m";
        String corVermelho = "\u001B[31m";

        for (int i = 0; i < caixas.length; i++) {
            Caixa caixa = caixas[i];
            System.out.println(corRoxo + "Caixa " + (i + 1) + ":" + corReset);
            Cliente clienteAtual = caixa.getClienteAtual();
            if (clienteAtual != null) {
                System.out.println(corRoxo + "  Cliente sendo atendido: " + corReset + "Nº " + clienteAtual.getNumeroSequencial() + 
                                   " (Tempo restante: " + clienteAtual.getTempoAtendimento() + " minutos)");
            } else {
                System.out.println(corVermelho + "  Nenhum cliente sendo atendido." + corReset);
            }
            System.out.print(corRoxo + "  Fila: " + corReset);
            Noh atual = caixa.getFila().getInicio();
            if (atual == null){
                System.out.println(corVermelho + "Nenhum cliente na fila." + corReset);
            }
            while (atual != null) {
                System.out.print(corCiano + atual.getCliente().getNumeroSequencial() + " " + corReset);
                atual = atual.getProximo();
            }
            System.out.println();
        }
    }
}