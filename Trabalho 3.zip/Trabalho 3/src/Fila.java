/**
 * Autoras: Lívia Viana Barbosa liviabarbosa.aluno@unipampa.edu.br
 *          Luiza de Campos Velasque Figueiredo luizavelasque.aluno@unipampa.edu.br
 * 
 * Esta classe mostra uma fila genérica de elementos, utilizada para simular uma fila 
 * para o atendimento de um caixa em um supermercado. Aqui se encontram operações para 
 * enfileirar e desinfileirar um cliente da fila de espera, consultar qual cliente deve 
 * ser atendido primeiro e operações de verificação básicas.
 */
public class Fila {
    private Noh inicio;
    private Noh fim;
    private int tamanho;
    
    /**
     * Construtor da classe Fila. 
     * 
     * Inicializa uma fila vazia com tamanho inicial igual a 0.
     */
    public Fila() {
        this.inicio = null;
        this.fim = null;
        this.tamanho = 0;
    }
    
    /**
     * Verifica se a fila está vazia.
     * 
     * @return true se a fila estiver vazia, false caso contrário.
     */
    public boolean estaVazia() {
        return inicio == null;
    }
    
    /**
     * Adiciona um cliente ao final da fila.
     * 
     * @param cliente O cliente a ser enfileirado.
     */
    public void enfileirar(Cliente cliente) {
        Noh novoNo = new Noh(cliente);
        if (estaVazia()) {
            inicio = novoNo;
        } else {
            fim.setProximo(novoNo);
        }
        fim = novoNo;
        tamanho++;
    }
    
    /**
     * Remove e retorna o cliente que está no início da fila.
     * 
     * @return O cliente que foi desenfileirado, ou null se a fila estiver vazia.
     */
    public Cliente desenfileirar() {
        if (estaVazia()) {
            return null;
        }
        Cliente cliente = inicio.getCliente();
        inicio = inicio.getProximo();
        if (inicio == null) {
            fim = null;
        }
        tamanho--;
        return cliente;
    }
    
    /**
     * Consulta o cliente que está no início da fila, sem removê-lo.
     * 
     * @return O cliente no início da fila, ou null se a fila estiver vazia.
     */
    public Cliente consultarPrimeiro() {
        return estaVazia() ? null : inicio.getCliente();
    }
    
    public int getTamanho() {
        return tamanho;
    }

    public Noh getInicio() {
        return inicio;
    }
}