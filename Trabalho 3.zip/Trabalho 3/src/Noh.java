/**
 * Autoras: Lívia Viana Barbosa liviabarbosa.aluno@unipampa.edu.br
 *          Luiza de Campos Velasque Figueiredo luizavelasque.aluno@unipampa.edu.br
 * 
 * Esta classe mostra as operações gerais de um nó utilizado em estruturas de dados 
 * encadeadas. Ela representa um nó que contém um cliente e mantém uma referência para 
 * o próximo nó na estrutura.
 */
public class Noh {
    private Cliente cliente;
    private Noh proximo;
    
    /**
     * Construtor da classe Noh.
     * 
     * Inicializa um nó com um cliente específico.
     * 
     * @param cliente O cliente que será armazenado neste nó.
     */
    public Noh(Cliente cliente) {
        this.cliente = cliente;
        this.proximo = null;
    }
    
    public Cliente getCliente() {
        return cliente;
    }
    
    public Noh getProximo() {
        return proximo;
    }
    
    public void setProximo(Noh proximo) {
        this.proximo = proximo;
    }
}