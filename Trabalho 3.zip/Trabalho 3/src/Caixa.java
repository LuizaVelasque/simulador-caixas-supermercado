/**
 * Autoras: Lívia Viana Barbosa liviabarbosa.aluno@unipampa.edu.br
 *          Luiza de Campos Velasque Figueiredo luizavelasque.aluno@unipampa.edu.br
 * 
 * Esta classe mostra as operações do caixa, onde um cliente pode ser atendido ou 
 * ficar na fila no caso de outro cliente estar sendo atendido no momento em que
 * chega no caixa.
 */
public class Caixa {
    private Fila fila;
    private Cliente clienteAtual;
    
    /**
     * Construtor da classe Caixa.
     * 
     * Inicializa um novo caixa com uma fila vazia e sem cliente sendo atendido.
     */
    public Caixa() {
        this.fila = new Fila();
        this.clienteAtual = null;
    }
    
    /**
     * Método para adicionar um cliente à fila para ser atendido posteriormente.
     * 
     * @param cliente O cliente a ser adicionado na fila.
     */
    public void adicionarCliente(Cliente cliente) {
        fila.enfileirar(cliente);
    }
    
    /**
     * Método para atender o próximo cliente da fila, se não houver um cliente
     * sendo atualmente atendido.
     * 
     * O cliente atual decrementa o tempo de atendimento a cada chamada deste método,
     * até que o tempo de atendimento seja zero, indicando que o cliente foi atendido
     * completamente.
     */
    public void atenderCliente() {
        if (clienteAtual == null && !fila.estaVazia()) {
            clienteAtual = fila.desenfileirar();
        }
        if (clienteAtual != null) {
            clienteAtual.decrementarTempo();
            if (clienteAtual.getTempoAtendimento() == 0) {
                clienteAtual = null;
            }
        }
    }
    
    public Cliente getClienteAtual() {
        return clienteAtual;
    }
    
    public Fila getFila() {
        return fila;
    }
}
