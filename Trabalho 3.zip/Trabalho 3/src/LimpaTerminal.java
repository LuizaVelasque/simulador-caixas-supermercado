/**
 * Autoras: Lívia Viana Barbosa liviabarbosa.aluno@unipampa.edu.br
 *          Luiza de Campos Velasque Figueiredo luizavelasque.aluno@unipampa.edu.br
 * 
 * Esta classe mostra uma operação geral útil para a estética do código, a qual é 
 * responsável por limpar o terminal em um determinado momento da aplicação.
 */
public class LimpaTerminal {
    /**
     * Método para limpar o terminal de acordo com o sistema operacional.
     * 
     * Utiliza comandos específicos para limpar o terminal dependendo do sistema operacional:
     * - No Windows, utiliza "cmd /c cls" para limpar o prompt de comando.
     * - Em outros sistemas, utiliza "clear" para limpar o terminal.
     * 
     * Caso ocorra alguma exceção ao tentar limpar o terminal, imprime 50 linhas em branco como alternativa.
     */
    @SuppressWarnings("deprecation")
    public void limparTerminal() {
        try {
            final String os = System.getProperty("os.name");
            if (os.contains("Windows")) {
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            } else {
                Runtime.getRuntime().exec("clear");
            }
        } catch (final Exception e) {
            for (int i = 0; i < 50; i++) {
                System.out.println();
            }
        }
    }
}